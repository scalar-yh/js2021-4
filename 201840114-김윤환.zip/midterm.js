let i = 0;
let sum = 0;

for (let i = 0; i<=100; i++) {
    if (i%3 == 0 && i%2 == 0) {
        console.log("+",i);
        sum += i;
        console.log("=", sum);
    }
}
var hw = document.write('hw');
hw.addEventListener('click', function(){
    alert('Hello world');
});